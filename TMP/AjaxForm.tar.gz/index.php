<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Grayscale</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <!-- Theme CSS -->
    <link href="css/grayscale.css" rel="stylesheet">
    <link href="css/contact.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    Lucky D <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">
                    <i class="fa fa-play-circle"></i>
                    <span class="light">Start</span>
                    Bootstrap
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                <ul class="nav navbar-nav">
                    <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                    <li class="hidden"><a href="#page-top"></a></li>
                    <li><a class="page-scroll" href="#about">About</a></li>
                    <li><a class="page-scroll" href="#download">Download</a></li>
                    <li><a class="page-scroll" href="#contact">Contact</a></li>
                    <li><a class="page-scroll" href="/?pl">pl</a></li>
                    <li><a class="page-scroll" href="/?en">en</a></li>
                    <li><a class="page-scroll" href="/?ru">ru</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Intro Header -->
    <header class="intro">
        <div class="intro-body">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h1 class="brand-heading">Grayscale</h1>
                        <p class="intro-text">A free, responsive, one page Bootstrap theme.
                            <br>Created by Start Bootstrap.</p>
                        <a href="#about" class="btn btn-circle page-scroll">
                            <i class="fa fa-angle-double-down animated"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- About Section -->
    <section id="about" class="container content-section text-center">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <h2>About Grayscale</h2>
                <p>Grayscale is a free Bootstrap 3 theme created by Start Bootstrap. It can be yours right now, simply download the template on <a href="http://startbootstrap.com/template-overviews/grayscale/">the preview page</a>. The theme is open source, and you can use it for any purpose, personal or commercial.</p>
                <p>This theme features stock photos by <a href="http://gratisography.com/">Gratisography</a> along with a custom Google Maps skin courtesy of <a href="http://snazzymaps.com/">Snazzy Maps</a>.</p>
                <p>Grayscale includes full HTML, CSS, and custom JavaScript files along with LESS files for easy customization.</p>
            </div>
        </div>
    </section>

    <!-- Download Section -->
    <section id="download" class="content-section text-center">
        <div class="download-section">
            <div class="container">
                <div class="col-lg-8 col-lg-offset-2">
                    <h2>Download Grayscale</h2>
                    <p>You can download Grayscale for free on the preview page at Start Bootstrap.</p>
                    <a href="http://startbootstrap.com/template-overviews/grayscale/" class="btn btn-default btn-lg">Visit Download Page</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact">
        <div class="row">
                  <div class="container">
                      <div class="row">
                          <div class="about_our_company" style="margin: 20px 20px;">
                              <h1 style="color:#fff;">Write Your Message</h1>
                              <p style="color:#fff;">Lorem Ipsum is simply dummy text of the printing and typesetting </p>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-lg-8">
                              <form name="sentMessage" id="contactForm" novalidate="">
                                  <div class="row">
                                      <div class="col-md-6">
                                          <div class="form-group">
                                              <input type="text" class="form-control" placeholder="Your Name *" id="name" required="" data-validation-required-message="Please enter your name.">
                                              <p class="help-block text-danger"></p>
                                          </div>
                                          <div class="form-group">
                                              <input type="email" class="form-control" placeholder="Your Email *" id="email" required="" data-validation-required-message="Please enter your email address.">
                                              <p class="help-block text-danger"></p>
                                          </div>
                                          <div class="form-group">
                                              <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" required="" data-validation-required-message="Please enter your phone number.">
                                              <p class="help-block text-danger"></p>
                                          </div>
                                      </div>
                                      <div class="col-md-6">
                                          <div class="form-group">
                                          <textarea class="form-control" placeholder="Your Message *" id="message" required="" data-validation-required-message="Please enter a message."></textarea>
                                          <p class="help-block text-danger"></p>
                                          </div>
                                      </div>
                                      <div class="clearfix"></div>
                                      <div class="col-lg-12 text-center">
                                          <div id="success"></div>
                                          <button type="submit" class="btn btn-xl get">Send Message</button>
                                      </div>
                                  </div>
                              </form>
                          </div>
                          <div class="col-lg-4">
                              <p style="color:#fff;">
                                  <strong><i class="fa fa-map-marker"></i> Address</strong>
                                  <br>1216/Mirpur_10 Beach, Dhaka(Bangladesh)
                              </p>
                              <p style="color:#fff;"><strong><i class="fa fa-phone"></i> Phone Number</strong>
                              <br>(+8801)7123456</p>
                              <p style="color:#fff;">
                                  <strong><i class="fa fa-envelope"></i>  Email Address</strong>
                                  <br>Email@info.com</p>
                              <p></p>
                          </div>
                      </div>
                  </div>
            </div>
        <!-- </div> -->
    </section>

    <!-- Map Section -->
    <!-- Google Maps API Key - Use your own API key to enable the map feature. More information on the Google Maps API can be found at https://developers.google.com/maps/ -->
    <!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRngKslUGJTlibkQ3FkfTxj3Xss1UlZDA&sensor=false"></script> -->
 <script>
    function initMap() {
            // var napiaski = {lat: 50.104911, lng:19.923992};
            var dluga = {lat:50.068248, lng:19.938644};
            var map = new google.maps.Map(document.getElementById('map'), {
              zoom: 16,
              // styles: [ {
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#212121"}]
              //         },
              //         {
              //           "elementType": "labels.icon",
              //           "stylers": [{"visibility": "off"}]
              //         },
              //         {
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#757575"}]
              //         },
              //         {
              //           "elementType": "labels.text.stroke",
              //           "stylers": [{"color": "#212121"}]
              //         },
              //         {
              //           "featureType": "administrative",
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#757575"}]
              //         },
              //         {
              //           "featureType": "administrative.country",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#9e9e9e"}]
              //         },
              //         {
              //           "featureType": "administrative.land_parcel",
              //           "stylers": [{"visibility": "off"}]
              //         },
              //         {
              //           "featureType": "administrative.locality",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#bdbdbd"}]
              //         },
              //         {
              //           "featureType": "poi",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#757575"}]
              //         },
              //         {
              //           "featureType": "poi.park",
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#181818"}]
              //         },
              //         {
              //           "featureType": "poi.park",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#616161"}]
              //         },
              //         {
              //           "featureType": "poi.park",
              //           "elementType": "labels.text.stroke",
              //           "stylers": [{"color": "#1b1b1b"}]
              //         },
              //         {
              //           "featureType": "road",
              //           "elementType": "geometry.fill",
              //           "stylers": [{"color": "#2c2c2c"}]
              //         },
              //         {
              //           "featureType": "road",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#8a8a8a"}]
              //         },
              //         {
              //           "featureType": "road.arterial",
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#373737"}]
              //         },
              //         {
              //           "featureType": "road.highway",
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#3c3c3c"}]
              //         },
              //         {
              //           "featureType": "road.highway.controlled_access",
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#4e4e4e"}]
              //         },
              //         {
              //           "featureType": "road.local",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#616161"}]
              //         },
              //         {
              //           "featureType": "transit",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#757575"}]
              //         },
              //         {
              //           "featureType": "water",
              //           "elementType": "geometry",
              //           "stylers": [{"color": "#000000"}]
              //         },
              //         {
              //           "featureType": "water",
              //           "elementType": "labels.text.fill",
              //           "stylers": [{"color": "#3d3d3d"}]
              //         }
              //       ],
              // center: napiaski
              center: dluga
            });
            var marker = new google.maps.Marker({
              position: dluga,
              // position: napiaski,
              // icon: {
              //     path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
              //     scale: 10,
              // },
              animation: google.maps.Animation.DROP,
              title: "Yukai",
              map: map
            });
    }
    function toggleBounce() {
      if (marker.getAnimation() !== null) {
        marker.setAnimation(null);
      } else {
        marker.setAnimation(google.maps.Animation.BOUNCE);
      }
    }

    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRngKslUGJTlibkQ3FkfTxj3Xss1UlZDA&callback=initMap&clickableIcons=false"
    async defer></script>


    <!-- <div id="map" style="position: relative; top: -248px;margin-bottom: -240px !important"></div> -->
    <div id="map"></div>

    <!-- Footer -->
    <footer>
        <div class="container text-center">
            <p>Copyright &copy; Your Website 2016</p>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery.easing.min.js"></script>



    <!-- Theme JavaScript -->
    <script src="js/grayscale.min.js"></script>

</body>

</html>
