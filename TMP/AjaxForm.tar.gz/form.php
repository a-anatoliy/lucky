<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/bootstrap-theme.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/animate.css">


    <title>Grayscale</title>

    <!-- Custom Fonts -->
    <link href="/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <!-- Theme CSS -->
<!--     <link href="/css/grayscale.css" rel="stylesheet">
    <link href="/css/underscores-contact.css" rel="stylesheet"> -->
    <!-- <link href="css/contact.css" rel="stylesheet"> -->
    <!-- <link href="css/underscores-contact.css" rel="stylesheet"> -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
    .jumbotron            { border-radius: 6px; font-family: "Montserrat", "Helvetica Neue", Helvetica, Arial, sans-serif; font-weight: 700; letter-spacing: 1px; color: gray; text-transform: uppercase; }
    .contact-header small { color: #666666; text-transform: uppercase; }
    .contact-button       { border-radius: 3px; }
    </style>
</head>

<!-- <body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top"> -->
<body>

   <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Bootstrap theme</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li role="separator" class="divider"></li>
                <li class="dropdown-header">Nav header</li>
                <li><a href="#">Separated link</a></li>
                <li><a href="#">One more separated link</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<br><br><br><br>
    <!-- Navigation -->
<!--     <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
              navbar-header
            </div>
        </div>
    </nav> -->

    <!-- Intro Header -->
    <!-- <header class="intro"> -->
        <!-- <div class="intro-body"> -->

 <div class="container">
        <div class="row">
            <div class="col-lg-12">
                ---INTRO BODY---
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                about -- col-lg-8 col-lg-offset-2
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                download -- col-lg-8 col-lg-offset-2
            </div>
        </div>
</div>
        <!-- </div> -->


    <!-- Download Section -->
    <!-- <section id="download" class="content-section text-center"> -->
        <!-- <div class="download-section"> -->
<!--             <div class="container">

            </div> -->
        <!-- </div> -->
    <!-- </section> -->

    <!-- Contact Section -->
    <!-- <section id="contact"> -->
<!-- contact form begin -->

<div class="container">
    <div class="row">
        <div class="col-sm-12 col-sm-12 text-center">
            <h4 class="contact-header jumbotron">Contact us <small>Feel free to contact us</small></h4>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-8">
                <form role="form" id="contactForm" data-toggle="validator" class="shake">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
<input type="text" class="form-control" name="name" id="name" placeholder="Enter your name *" required="required" autofocus="" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
<input type="email" class="form-control" name="email" id="email" placeholder="Enter your email " required="required" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
<input type="phone" class="form-control"  name="phone" id="phone" placeholder="Enter your phone no." onkeypress="return event.charCode >= 48 && event.charCode <= 57" maxlength="10" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
<textarea name="message" id="message" class="form-control" rows="6" cols="25" required="required" placeholder="Message"></textarea>
                        </div>
                    </div>
                    <div class="form-group">

                        <div class="col-md-12">
                            <button type="submit" id="form-submit" class="btn btn-primary pull-right contact-button">Send
                              <span class="glyphicon glyphicon-send"></span>
                            </button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                </form>
        </div>
        <div class="col-md-4">
            <legend><span class="glyphicon glyphicon-globe"></span> Our Location</legend>
            <address>
                <strong>propertiesguru.com</strong><br>
                617, West End Mall<br>
                Janakpuri, New Delhi - 110058<br>
                <abbr title="Phone">Phone</abbr>(+91) 9312 690 490
            </address>
            <address>Email: <a href="mailto:#">info@propertiesguru.com</a></address>
        </div>
    </div>
</div>
<!-- https://bootsnipp.com/snippets/7KmBe -->
<!-- contact form finish -->
<!--         <div class="row">
                  <div class="container">
                      <div class="row">
contact » container » row
                      </div>
                      <div class="row">
                          <div class="col-lg-8">
col-lg-8
                          </div>
                          <div class="col-lg-4">
col-lg-4
                          </div>
                      </div>
                  </div>
            </div> -->
    <!-- </section> -->


    <!-- Footer -->
    <footer>
        <div class="container text-center">
            <p>Copyright &copy; Your Website 2016</p>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="/vendor/jquery/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <!-- <script src="vendor/jquery.easing.min.js"></script> -->
    <script type="text/javascript" src="js/validator.min.js"></script>
    <script type="text/javascript" src="js/form-scripts.js"></script>


</body>
</html>




